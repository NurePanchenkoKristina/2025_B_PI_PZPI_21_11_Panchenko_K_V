// network.js
const API_BASE = 'http://localhost:8080/api';

class NetworkManager {
  constructor() {
    // Load token from localStorage if available
    this.token = localStorage.getItem('token') || null;
  }

  // Store token in memory and localStorage
  setToken(token) {
    this.token = token;
    localStorage.setItem('token', token);
  }

  // Remove token from both memory and localStorage
  clearToken() {
    this.token = null;
    localStorage.removeItem('token');
  }

  // Generic request method for all HTTP calls
  async request(endpoint, method = 'GET', body = null) {
    const headers = {
      'Content-Type': 'application/json',
    };

    // Add Authorization header if token is available
    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    const options = {
      method,
      headers,
    };

    if (body) {
      options.body = JSON.stringify(body);
    }

    try {
      const response = await fetch(`${API_BASE}${endpoint}`, options);

      // If unauthorized, clear token and redirect to login
      if (response.status === 401) {
        alert('Session expired. Please log in again.');
        this.clearToken();
        window.location.href = 'login.html';
        return;
      }

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Network error:', error);
      throw error;
    }
  }

  // Send login credentials to backend
  login(credentials) {
    return this.request('/auth/login', 'POST', credentials);
  }

  // Fetch current user's profile
  getProfile() {
    return this.request('/user/profile', 'GET');
  }

  // Update user's profile
  updateProfile(profileData) {
    return this.request('/user/profile', 'PUT', profileData);
  }

  // Refresh JWT token (if supported by backend)
  async refreshToken() {
    const response = await fetch(`${API_BASE}/auth/refresh`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${this.token}` }
    });

    const data = await response.json();
    if (data.token) this.setToken(data.token);
  }

  // Clear token and redirect to login
  logout() {
    this.clearToken();
    window.location.href = 'login.html';
  }

  // Check if token is available (user is logged in)
  isAuthenticated() {
    return !!this.token;
  }

  // Load available language courses
  getCourses() {
    return this.request('/courses', 'GET');
  }

  // Get user's progress and activity data
  getProgress() {
    return this.request('/user/progress', 'GET');
  }

  // Subscribe to a plan (monthly or annual)
  subscribe(planType) {
    return this.request('/billing/subscribe', 'POST', { plan: planType });
  }
}

// Create and export instance of NetworkManager
const network = new NetworkManager();
export default network;
