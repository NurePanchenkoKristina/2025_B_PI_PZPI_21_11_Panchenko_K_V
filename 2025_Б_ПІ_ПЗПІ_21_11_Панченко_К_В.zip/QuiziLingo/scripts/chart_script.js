import network from './network.js';

document.addEventListener('DOMContentLoaded', async () => {
  let progressData = [];
  try {
      progressData = await network.getProgress();
    } catch (e) {
      progressData = {
        labels: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
        values: [0, 0, 0, 0, 0, 5, 0]
      };
    }
  const ctx = document.getElementById('activityChart').getContext('2d');
  new Chart(ctx, {
    type: 'line',
    data: {
      labels: progressData.labels,
      datasets: [{
        label: 'Min',
        data: progressData.values,
        backgroundColor: 'rgba(255, 102, 0, 0.1)',
        borderColor: '#ff6600',
        pointBackgroundColor: '#ff6600',
        borderWidth: 3,
        tension: 0.4,
        fill: true
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { display: false }
      },
      scales: {
        y: {
          beginAtZero: true,
          max: 25,
          ticks: {
            stepSize: 5,
            callback: value => `${value}min`
          }
        }
      }
    }
  });
});
