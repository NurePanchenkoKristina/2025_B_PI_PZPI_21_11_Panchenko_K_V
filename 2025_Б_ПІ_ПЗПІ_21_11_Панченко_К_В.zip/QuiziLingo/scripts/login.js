import network from './network.js';

document.querySelector('.login-button').addEventListener('click', async (e) => {
  e.preventDefault();

  const email = document.querySelector('#email').value;
  const password = document.querySelector('#password').value;

  try {
    const res = await network.login({ email, password });
    if (res.token) {
      network.setToken(res.token);
      window.location.href = 'profile.html';
    } else {
      alert('Login failed.');
    }
  } catch (err) {
    alert('Login error');
  }
});
